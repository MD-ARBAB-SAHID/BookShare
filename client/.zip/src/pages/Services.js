const Services = ()=>{
    return(
        <div className='box'>Services</div>
    )
}
export default Services;