import HomePage from '../components/Home/HomePage'
const Home = ()=>{
    return(
        <HomePage/>
    )
}
export default Home;