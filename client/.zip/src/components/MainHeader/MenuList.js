export const MenuList = [
    {
        title : "Home",
        url : "/",
    },
    {
        title : "Profile",
        url : "/profile",
    },
    {
        title : "Services",
        url : "/services",
    },
]